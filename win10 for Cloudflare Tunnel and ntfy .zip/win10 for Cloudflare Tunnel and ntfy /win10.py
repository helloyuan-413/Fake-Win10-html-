#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
============================================================
  Win10 模拟桌面  -  纯标准库后端
  Version: 1.2.2
============================================================
  功能：
    ★ 虚拟根隔离 + 递归删除 + 系统目录识别
    ★ APK 安装 / 路径改写 / 运行安装后的 APP
    ★ 图形代码后端暂存 + token 分发
    ★ ZIP 压缩 / 解压
    ★ 二进制文件上传（base64 兼容层）
    ★ 隧道：cloudflared Quick Tunnel
    ★ 地址广播：ntfy.sh（APK 自动获取最新地址）

  运行：
    cd ~ && python win10.py

  依赖（仅标准库 + 可选 cloudflared）：
    pkg install cloudflared -y
============================================================
"""

import os, sys, json, time, uuid as uuidlib, hashlib, threading, base64, io
import subprocess, re, ast, atexit, sqlite3, secrets, queue, shutil, shlex, zipfile
import urllib.request, urllib.error, traceback
from datetime import datetime
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote, quote

# ============================================================
# 配置区
# ============================================================
VERSION = "1.2.2"

BASE_DIR   = Path(__file__).parent.resolve()
DATA_DIR   = BASE_DIR / "data"
FILES_DIR  = DATA_DIR / "files"
DB_PATH    = DATA_DIR / "win10.db"
INDEX_HTML = BASE_DIR / "index.html"

HOST = "0.0.0.0"
PORT = 8000

# Ollama
OLLAMA_HOST = "http://127.0.0.1:11434"
PREFERRED_MODELS = ["qwen2:0.5b","qwen2.5:0.5b","qwen2:1.5b","qwen2.5:1.5b",
                    "tinyllama:latest","gemma:2b"]

# ntfy 广播 topic（APK 里填的必须一致）
NTFY_TOPIC = "win10-tunnel-a7k2p9x8m3"

# 系统目录白名单
SYSTEM_DIR_WHITELIST = {'etc','home','tmp','var','usr','bin','opt',
                        'drives','libs','root','proc','sys','dev'}

# ============================================================
# 目录初始化
# ============================================================
DATA_DIR.mkdir(parents=True, exist_ok=True)
(FILES_DIR / "private").mkdir(parents=True, exist_ok=True)
(FILES_DIR / "public").mkdir(parents=True, exist_ok=True)

_gfx_stage = {}
_gfx_lock = threading.Lock()
GFX_TTL = 300

# ============================================================
# 数据库
# ============================================================
def init_db():
    conn = sqlite3.connect(DB_PATH); c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        uuid TEXT PRIMARY KEY, name TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL, created REAL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT, from_uuid TEXT,
        to_uuid TEXT, content TEXT, time REAL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS files (
        uuid TEXT, scope TEXT, name TEXT, hidden INTEGER DEFAULT 0,
        created REAL, PRIMARY KEY (uuid, scope, name))''')
    c.execute('''CREATE TABLE IF NOT EXISTS shares (
        token TEXT PRIMARY KEY, uuid TEXT, scope TEXT, name TEXT, created REAL)''')
    c.execute('''CREATE INDEX IF NOT EXISTS idx_shares_lookup
                 ON shares (uuid, scope, name)''')
    conn.commit(); conn.close()

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def hash_pw(pw):
    return hashlib.sha256(pw.encode("utf-8")).hexdigest()

init_db()

# ============================================================
# 路径工具
# ============================================================
PUBLIC_UUID = "__public__"

def db_uid(uid, scope):
    return PUBLIC_UUID if scope == "public" else uid

def user_root(uid, scope):
    if scope == "public":
        d = FILES_DIR / "public"
    else:
        if not re.match(r'^[a-zA-Z0-9_\-]{1,64}$', uid or ''):
            raise ValueError("非法 UUID")
        d = FILES_DIR / "private" / uid
    d.mkdir(parents=True, exist_ok=True)
    return d

def safe_rel(name):
    name = (name or "").strip().replace("\\", "/").strip("/")
    if not name:
        return ""
    parts = []
    for seg in name.split("/"):
        if seg in ("", "."):
            continue
        if seg == "..":
            raise ValueError("非法路径")
        parts.append(seg)
    return "/".join(parts)

def full_path(uid, scope, name):
    root = user_root(uid, scope)
    rel = safe_rel(name)
    if not rel:
        return root
    p = (root / rel).resolve()
    try:
        p.relative_to(root.resolve())
    except ValueError:
        raise ValueError("路径逃逸")
    return p

# ============================================================
# base64 兼容层
# ============================================================
_B64_MAGIC_LIST = (
    '[二进制文件，base64 编码]'.encode('utf-8'),
    '[Binary file, base64 encoded]'.encode('utf-8'),
    '[二进制文件,base64编码]'.encode('utf-8'),
)

def read_file_bytes_smart(p):
    try:
        raw = p.read_bytes()
    except Exception:
        return b""
    for magic in _B64_MAGIC_LIST:
        if raw.startswith(magic):
            idx = raw.find(b'\n')
            if idx > 0:
                try:
                    return base64.b64decode(raw[idx+1:].strip())
                except Exception:
                    return raw
    if not raw.startswith(b'PK\x03\x04') and not raw.startswith(b'PK\x05\x06'):
        try:
            txt = raw.decode('ascii', errors='strict').strip()
            if len(txt) > 128 and re.match(r'^[A-Za-z0-9+/=\s]+$', txt):
                decoded = base64.b64decode(txt)
                if decoded.startswith(b'PK\x03\x04'):
                    return decoded
        except Exception:
            pass
    return raw

def zipfile_open_smart(p, mode="r"):
    data = read_file_bytes_smart(p)
    return zipfile.ZipFile(io.BytesIO(data), mode)

# ============================================================
# Ollama
# ============================================================
_progress = {}
_progress_lock = threading.Lock()
_chosen_model = None
_model_lock = threading.Lock()

FALLBACK = [
    "窗外的阳光洒进来，温暖了整个房间。",
    "小猫安静地趴在沙发上打盹。",
    "远处的山峦在薄雾中若隐若现。",
    "他轻轻地合上书本，深吸一口气。",
]

def http_get_json(url, timeout=5):
    try:
        with urllib.request.urlopen(
                urllib.request.Request(url), timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None

def http_post_json(url, data, timeout=120):
    try:
        body = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(
            url, data=body,
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception as e:
        return {"_error": str(e)}

def ollama_alive():
    return http_get_json(OLLAMA_HOST + "/api/tags", timeout=2) is not None

def pick_model():
    global _chosen_model
    with _model_lock:
        if _chosen_model:
            return _chosen_model
        data = http_get_json(OLLAMA_HOST + "/api/tags", timeout=5) or {}
        models = [m["name"] for m in data.get("models", [])]
        for pref in PREFERRED_MODELS:
            for m in models:
                if m == pref or m.startswith(pref + ":"):
                    _chosen_model = m
                    return m
        _chosen_model = models[0] if models else "qwen2:0.5b"
        return _chosen_model

def ensure_ollama():
    if ollama_alive():
        print("[Ollama] 已在运行")
        return True
    print("[Ollama] 启动中...")
    try:
        subprocess.Popen(["ollama", "serve"],
                         stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL,
                         start_new_session=True)
    except FileNotFoundError:
        print("[Ollama] 未安装")
        return False
    for _ in range(30):
        time.sleep(1)
        if ollama_alive():
            print("[Ollama] 已启动")
            return True
    return False

def _job_is_current(uid, job_id):
    with _progress_lock:
        p = _progress.get(uid)
        return bool(p) and p.get("job_id") == job_id

def generate_sentences(uid, job_id, count=4):
    try:
        model = pick_model()
        sentences = []
        for _ in range(count):
            if not _job_is_current(uid, job_id):
                return
            prompt = ("请写一句中文句子，长度 20 到 40 字，"
                      "内容日常、有趣、积极向上。只输出句子本身，"
                      "不要引号、不要编号、不要解释。")
            body = {
                "model": model, "prompt": prompt, "stream": False,
                "keep_alive": "30s",
                "options": {"num_ctx": 256, "num_predict": 80,
                            "temperature": 0.9, "top_p": 0.9,
                            "num_thread": 2}
            }
            resp = http_post_json(OLLAMA_HOST + "/api/generate", body, timeout=120)
            if not _job_is_current(uid, job_id):
                return
            if resp and "response" in resp:
                text = (resp.get("response") or "").strip()
                text = re.sub(r'^["“”\'\s]+|["“”\'\s]+$', "", text)
                text = re.sub(r"^\d+[\.\、\s]+", "", text)
                if text:
                    sentences.append(text)
                    with _progress_lock:
                        p = _progress.get(uid)
                        if p and p.get("job_id") == job_id:
                            p["received"] = p.get("received", 0) + len(text)
        while len(sentences) < count:
            sentences.append(FALLBACK[len(sentences) % len(FALLBACK)])
        with _progress_lock:
            p = _progress.get(uid)
            if p and p.get("job_id") == job_id:
                p["status"] = "ready"
                p["received"] = sum(len(s) for s in sentences)
                p["sentences"] = sentences
    except Exception:
        with _progress_lock:
            p = _progress.get(uid)
            if p and p.get("job_id") == job_id:
                p["status"] = "ready"
                p["received"] = 0
                p["sentences"] = list(FALLBACK)

# ============================================================
# APK 安装 / 路径改写 / 运行
# ============================================================
APK_TEXT_EXTS = {'.txt','.json','.xml','.html','.htm','.js','.css','.properties',
                 '.cfg','.ini','.yaml','.yml','.md','.csv','.conf','.log',
                 '.sh','.bat','.cmd','.py','.gradle','.kt','.java'}

_PKG_SKIP_PREFIX = ("android.","androidx.","com.android.","com.google.android.",
                    "org.apache.","java.","javax.","kotlin.","org.jetbrains.",
                    "dalvik.")

APK_ENTRY_CANDIDATES = [
    ("index.html","html"), ("index.htm","html"),
    ("main.py","python"),  ("app.py","python"),
    ("main.js","node"),    ("app.js","node"),
    ("run.sh","shell"),    ("main.sh","shell"), ("run.bat","shell"),
]

def apk_guess_package(zf, fallback):
    raw = b""
    try:
        raw = zf.read("AndroidManifest.xml")
    except Exception:
        pass
    counts = {}
    for m in re.finditer(
            rb'[a-z][a-z0-9_]{1,30}(?:\.[a-z][a-z0-9_]{1,30}){1,5}',
            raw or b""):
        s = m.group(0).decode("ascii", "ignore")
        if 2 <= s.count(".") <= 4 and not s.startswith(_PKG_SKIP_PREFIX):
            counts[s] = counts.get(s, 0) + 1
    if counts:
        return max(counts.items(), key=lambda kv: kv[1])[0]
    base = re.sub(r'[^A-Za-z0-9_.\-]+', '_', fallback or "app").strip('._-') or "app"
    if "." not in base:
        base = "com.example." + base
    return base

def apk_rewrite_bytes(data, pkg_names, install_dir):
    inst_b = install_dir.encode("utf-8")
    total = 0
    for pkg in pkg_names:
        if not pkg:
            continue
        pb = pkg.encode("utf-8")
        pats = [
            (re.compile(rb'/data/user/0/' + re.escape(pb)), inst_b + b'/data'),
            (re.compile(rb'/data/data/' + re.escape(pb)), inst_b + b'/data'),
            (re.compile(rb'/storage/emulated/0/Android/data/' + re.escape(pb)),
             inst_b + b'/sdcard'),
            (re.compile(rb'/sdcard/Android/data/' + re.escape(pb)),
             inst_b + b'/sdcard'),
            (re.compile(rb'/Android/data/' + re.escape(pb)),
             inst_b + b'/sdcard'),
        ]
        for pat, rep in pats:
            data, n = pat.subn(rep, data)
            total += n
    for pat, rep in [
        (re.compile(rb'/storage/emulated/0'), inst_b + b'/sdcard'),
        (re.compile(rb'/sdcard/'),            inst_b + b'/sdcard/'),
    ]:
        data, n = pat.subn(rep, data)
        total += n
    return data, total

def apk_find_entry(app_dir):
    for base in (app_dir / "content", app_dir):
        if not base.exists() or not base.is_dir():
            continue
        for fname, kind in APK_ENTRY_CANDIDATES:
            p = base / fname
            if p.exists() and p.is_file():
                return kind, fname, p
    return "", "", None

def apk_install(uid, scope, name):
    src = full_path(uid, scope, name)
    if not src.exists() or not src.is_file():
        raise ValueError("APK 文件不存在")
    if src.suffix.lower() != ".apk":
        raise ValueError("不是有效的 APK 文件")

    try:
        apk_bytes = read_file_bytes_smart(src)
    except Exception as e:
        raise ValueError(f"读取 APK 失败：{e}")

    if not apk_bytes.startswith(b'PK'):
        raise ValueError(
            "这个文件不是有效的 APK（ZIP 头缺失）。\n"
            "可能原因：文件在传输/导入时被改写成了文本。\n"
            "请用 MT 管理器直接放入原始 APK 二进制文件。"
        )

    root = user_root(uid, scope)
    apps_root = root / "apps"
    apps_root.mkdir(parents=True, exist_ok=True)

    stage = apps_root / (".stage_" + secrets.token_hex(6))
    if stage.exists():
        shutil.rmtree(str(stage), ignore_errors=True)
    stage.mkdir(parents=True, exist_ok=True)

    pkg = ""
    safe_pkg = ""
    app_dir = None
    entry = ""
    kind = ""
    rewritten = 0
    file_count = 0

    try:
        with zipfile.ZipFile(io.BytesIO(apk_bytes), "r") as zf:
            pkg = apk_guess_package(zf, src.stem)
            safe_pkg = (re.sub(r'[^A-Za-z0-9_.\-]+', '_', pkg).strip('._-')
                        or ("app_" + secrets.token_hex(4)))
            app_dir = apps_root / safe_pkg
            install_str = str(app_dir)

            content_dir = stage / "content"
            content_dir.mkdir(parents=True, exist_ok=True)

            items = []
            for info in zf.infolist():
                norm = (info.filename or "").replace("\\", "/").lstrip("/")
                if ".." in norm.split("/"):
                    continue
                if info.is_dir():
                    items.append((info, None))
                    continue
                try:
                    raw = zf.read(info.filename)
                except Exception:
                    continue
                file_count += 1
                ext = os.path.splitext(info.filename)[1].lower()
                new_raw = raw
                if ext in APK_TEXT_EXTS:
                    new_raw, k = apk_rewrite_bytes(raw, {pkg, safe_pkg}, install_str)
                    rewritten += k
                items.append((info, new_raw))
                try:
                    target = content_dir / norm
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(new_raw)
                except Exception:
                    pass

            tmp_apk = stage / "app.apk"
            with zipfile.ZipFile(str(tmp_apk), "w", zipfile.ZIP_DEFLATED) as zout:
                for info, data in items:
                    zi = zipfile.ZipInfo(info.filename, date_time=info.date_time)
                    zi.external_attr = info.external_attr
                    zi.compress_type = zipfile.ZIP_DEFLATED
                    zout.writestr(zi, data if data is not None else b"")

        (stage / "data").mkdir(exist_ok=True)
        (stage / "sdcard").mkdir(exist_ok=True)

        kind, entry, _ = apk_find_entry(stage)
        meta = {
            "package": safe_pkg,
            "source": name,
            "installed_at": time.time(),
            "installed_at_str": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "rewritten_paths": rewritten,
            "files": file_count,
            "entry": entry,
            "kind": kind,
        }
        (stage / "meta.json").write_text(
            json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

        if app_dir.exists():
            shutil.rmtree(str(app_dir), ignore_errors=True)
        shutil.move(str(stage), str(app_dir))
    except zipfile.BadZipFile:
        shutil.rmtree(str(stage), ignore_errors=True)
        raise ValueError("APK 内部 ZIP 结构损坏，无法解压")
    except Exception:
        shutil.rmtree(str(stage), ignore_errors=True)
        raise

    try:
        if src.exists() and src.is_file():
            src.unlink()
    except Exception:
        pass

    def _rel(p):
        return str(p.relative_to(root)).replace(os.sep, "/")

    return {
        "ok": True, "pkg": safe_pkg, "source": name,
        "app_dir": _rel(app_dir), "apk": _rel(app_dir / "app.apk"),
        "entry": entry, "kind": kind,
        "rewritten": rewritten, "files": file_count,
    }

# ============================================================
# Shell 会话
# ============================================================
_shell_sessions = {}
_shell_sessions_lock = threading.Lock()

def shell_pick_python():
    return "python" if os.name == "nt" else "python3"

def shell_user_root(uuid):
    return user_root(uuid, "private")

def shell_user_libs(uuid):
    d = shell_user_root(uuid) / "libs"
    d.mkdir(parents=True, exist_ok=True)
    return d

def shell_bootstrap_root(uuid):
    root = shell_user_root(uuid)
    for d in ["etc","home","tmp","var","usr","bin","opt",
              "drives/C","drives/D","libs"]:
        try:
            (root / d).mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    try:
        h = root / "etc" / "hosts"
        if not h.exists():
            h.write_text("127.0.0.1\tlocalhost\n::1\t\tlocalhost\n",
                         encoding="utf-8")
        p = root / "etc" / "passwd"
        if not p.exists():
            p.write_text(
                "root:x:0:0:root:/root:/bin/bash\n"
                "user:x:1000:1000:user:/home/user:/bin/bash\n",
                encoding="utf-8")
    except Exception:
        pass
    return root

_WIN_ABS_RE = re.compile(r'^([a-zA-Z]):[\\/](.*)$')
_URL_RE = re.compile(r'^[a-zA-Z][a-zA-Z0-9+.\-]*://')
_MIME_RE = re.compile(
    r'^(?:text|image|application|audio|video|font|multipart|message|model)/',
    re.I)
_REL_PATH_RE = re.compile(r'^[\w\-\.]+(?:[\\/][\w\-\.]+)+$')

def rewrite_path_string(s, virtual_root):
    if not s:
        return s
    root_str = str(virtual_root)
    if (s == root_str or s.startswith(root_str + os.sep)
            or s.startswith(root_str + "/")):
        return s
    if _URL_RE.match(s):
        return s
    m = _WIN_ABS_RE.match(s)
    if m:
        drive = m.group(1).upper()
        rest = m.group(2).replace("\\", "/")
        return root_str + "/drives/" + drive + "/" + rest
    if s.startswith("/"):
        return root_str + s
    if s.startswith("~"):
        rest = s[1:].lstrip("/\\")
        return root_str + "/home/" + rest if rest else root_str + "/home"
    if s.startswith("./"):
        return root_str + "/" + s[2:].lstrip("/")
    if s.startswith("../"):
        return root_str + "/" + s[3:].lstrip("/")
    if _REL_PATH_RE.match(s) and not _MIME_RE.match(s):
        return root_str + "/" + s.replace("\\", "/")
    return s

def looks_like_path_token(tok):
    if not tok or tok.startswith("-") or _URL_RE.match(tok):
        return False
    if tok.startswith("/") or tok.startswith("~") or tok.startswith("\\"):
        return True
    if _WIN_ABS_RE.match(tok):
        return True
    if _REL_PATH_RE.match(tok) and not _MIME_RE.match(tok):
        return True
    return False

def _shell_quote_for(quote_char, s):
    if quote_char == '"':
        escaped = (s.replace('\\', '\\\\').replace('"', '\\"')
                   .replace('$', '\\$').replace('`', '\\`'))
        return '"' + escaped + '"'
    if quote_char == "'":
        escaped = s.replace("'", "'\\''")
        return "'" + escaped + "'"
    if any(c in s for c in ' \t"\'\\|&;<>()$`*?[]{}!'):
        return shlex.quote(s)
    return s

def rewrite_cmdline_paths(cmdline, virtual_root):
    if not cmdline:
        return cmdline
    tokens = re.findall(r'"[^"]*"|\'[^\']*\'|\S+', cmdline)
    out = []
    for tok in tokens:
        quote_char = None
        inner = tok
        if len(tok) >= 2:
            if tok[0] == '"' and tok[-1] == '"':
                quote_char = '"'
                inner = tok[1:-1]
            elif tok[0] == "'" and tok[-1] == "'":
                quote_char = "'"
                inner = tok[1:-1]
        if looks_like_path_token(inner):
            new = rewrite_path_string(inner, virtual_root)
            out.append(_shell_quote_for(quote_char, new))
        else:
            out.append(tok)
    return " ".join(out)

class PythonPathRewriter(ast.NodeTransformer):
    def __init__(self, root):
        self.virtual_root = root
    def visit_Constant(self, node):
        if isinstance(node.value, str):
            new = rewrite_path_string(node.value, self.virtual_root)
            if new != node.value:
                node.value = new
        return node
    def visit_JoinedStr(self, node):
        for v in node.values:
            if isinstance(v, ast.Constant) and isinstance(v.value, str):
                new = rewrite_path_string(v.value, self.virtual_root)
                if new != v.value:
                    v.value = new
        return node

def rewrite_python_source(src, root):
    if not src:
        return src
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return src
    try:
        tree = PythonPathRewriter(root).visit(tree)
        ast.fix_missing_locations(tree)
        return ast.unparse(tree)
    except Exception:
        return src

DANGEROUS = [re.compile(p, re.I) for p in [
    r'\bmkfs(\.\w+)?\b',
    r'\b(shutdown|reboot|halt|poweroff|init\s+0)\b',
    r'\bdiskpart\b', r'\bbcdedit\b', r'\bcipher\s+/w',
    r'\bnet\s+user\b[^\n]*/add', r'\breg\s+delete\b'
]]

def is_dangerous_command(cmd):
    return any(p.search(cmd) for p in DANGEROUS) if cmd else False

def extract_and_rewrite_python_in_cmd(cmdline, root):
    if not cmdline:
        return cmdline

    def _rw_c(m):
        qc = m.group(1)
        inner = qc[1:-1]
        code = (inner.replace('\\"', '"').replace("\\'", "'")
                .replace('\\n', '\n'))
        nc = rewrite_python_source(code, root)
        return '-c ' + shlex.quote(nc)

    cmdline = re.sub(r'-c\s+("(?:[^"\\]|\\.)*"|\'(?:[^\'\\]|\\.)*\')',
                     _rw_c, cmdline)

    for m in re.finditer(r'(?:python3?|py)\s+(\S+\.py)\b', cmdline, re.I):
        py = m.group(1)
        rel = py
        while rel.startswith('./') or rel.startswith('.\\'):
            rel = rel[2:]
        try:
            cand = (root / rel).resolve()
            cand.relative_to(root.resolve())
            if cand.exists() and cand.is_file():
                src = cand.read_text(encoding='utf-8', errors='replace')
                ns = rewrite_python_source(src, root)
                if ns != src:
                    cand.write_text(ns, encoding='utf-8')
        except Exception:
            pass
    return cmdline

# ============================================================
# 隧道（cloudflared）+ ntfy 广播
# ============================================================
TUNNEL_URL = None
_tunnel_proc = None
_tunnel_thread = None
_tunnel_lock = threading.Lock()

_url_re = re.compile(r"https://[a-zA-Z0-9\-]+\.trycloudflare\.com")
_ansi_re = re.compile(r"\x1b\[[0-9;?]*[a-zA-Z]")
_ctrl_re = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

def _clean_line(raw):
    s = _ansi_re.sub("", raw or "").replace("\r", "").replace("\b", "")
    return _ctrl_re.sub("", s).rstrip()

def _find_cloudflared():
    p = shutil.which("cloudflared")
    if p:
        return p
    for cand in [
        os.path.expanduser("~/cloudflared"),
        "/data/data/com.termux/files/usr/bin/cloudflared",
        "/usr/local/bin/cloudflared",
        "/usr/bin/cloudflared",
    ]:
        if os.path.exists(cand):
            return cand
    return ""

def _publish_ntfy(url):
    """把隧道地址推送到 ntfy.sh，APK 从那儿订阅"""
    if not NTFY_TOPIC:
        return
    try:
        req = urllib.request.Request(
            f"https://ntfy.sh/{NTFY_TOPIC}",
            data=url.encode("utf-8"), method="POST",
            headers={"Title": "win10-tunnel-url", "Priority": "high"})
        urllib.request.urlopen(req, timeout=10).read()
        print(f"[ntfy] 已广播: {url}")
    except Exception as e:
        print(f"[ntfy] 广播失败: {e}")

def _run_tunnel(local_port):
    global TUNNEL_URL, _tunnel_proc
    bin_path = _find_cloudflared()
    if not bin_path:
        print("[隧道] 未找到 cloudflared")
        print("[隧道] 请执行：pkg install cloudflared -y")
        return
    while True:
        try:
            print(f"[隧道] 启动 cloudflared ...")
            _tunnel_proc = subprocess.Popen(
                [bin_path, "tunnel", "--no-autoupdate",
                 "--url", f"http://localhost:{local_port}"],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1,
                env={**os.environ, "TERM": "dumb"})

            for raw in _tunnel_proc.stdout:
                line = _clean_line(raw)
                if not line:
                    continue
                m = _url_re.search(line)
                if m:
                    with _tunnel_lock:
                        if m.group(0) != TUNNEL_URL:
                            TUNNEL_URL = m.group(0)
                            print(f"[隧道] 公网地址: {TUNNEL_URL}")
                    threading.Thread(target=_publish_ntfy,
                                     args=(m.group(0),), daemon=True).start()

            _tunnel_proc.wait()
        except Exception as e:
            print("[隧道] 异常:", e)
        finally:
            with _tunnel_lock:
                TUNNEL_URL = None
        print("[隧道] 断开，5 秒后重连...")
        time.sleep(5)

def start_tunnel(port):
    global _tunnel_thread
    if _tunnel_thread and _tunnel_thread.is_alive():
        return
    _tunnel_thread = threading.Thread(target=_run_tunnel, args=(port,), daemon=True)
    _tunnel_thread.start()

def stop_tunnel():
    global _tunnel_proc
    if _tunnel_proc and _tunnel_proc.poll() is None:
        try:
            _tunnel_proc.terminate()
        except Exception:
            pass

atexit.register(stop_tunnel)

def get_public_base(h):
    with _tunnel_lock:
        if TUNNEL_URL:
            return TUNNEL_URL
    host = (h.headers.get("X-Forwarded-Host")
            or h.headers.get("Host") or f"localhost:{PORT}")
    scheme = h.headers.get("X-Forwarded-Proto") or "http"
    return f"{scheme}://{host}"

# ============================================================
# MIME
# ============================================================
MIME = {
    ".html": "text/html; charset=utf-8",
    ".htm":  "text/html; charset=utf-8",
    ".js":   "application/javascript; charset=utf-8",
    ".css":  "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png":  "image/png",
    ".jpg":  "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif":  "image/gif",
    ".svg":  "image/svg+xml",
    ".ico":  "image/x-icon",
    ".txt":  "text/plain; charset=utf-8",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
}

# ============================================================
# HTTP Handler
# ============================================================
class Handler(BaseHTTPRequestHandler):
    server_version = f"Win10Desktop/{VERSION}"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        try:
            sys.stderr.write("[HTTP] " + (fmt % args) + "\n")
        except Exception:
            pass

    def _json(self, obj, status=200):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()
        try:
            self.wfile.write(b)
        except Exception:
            pass

    def _text(self, t, status=200, ct="text/plain; charset=utf-8"):
        b = t.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        try:
            self.wfile.write(b)
        except Exception:
            pass

    def _file(self, p, attach=False):
        if not p.exists() or not p.is_file():
            return self._text("404", 404)
        try:
            data = p.read_bytes()
        except Exception:
            return self._text("读取失败", 500)
        ext = p.suffix.lower()
        ct = MIME.get(ext, "application/octet-stream")
        self.send_response(200)
        self.send_header("Content-Type", ct)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        if attach:
            rn = p.name
            an = rn.encode("ascii", "ignore").decode("ascii")
            an = (an.replace('"', '_').replace("\\", "_")
                  .replace("\r", "").replace("\n", ""))
            if not an.strip():
                an = "download" + (ext or "")
            un = quote(rn, safe="")
            self.send_header(
                "Content-Disposition",
                f'attachment; filename="{an}"; filename*=UTF-8\'\'{un}')
        self.end_headers()
        try:
            self.wfile.write(data)
        except Exception:
            pass

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0:
                return {}
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return {}

    def _q(self):
        return parse_qs(urlparse(self.path).query)

    def _p(self):
        return urlparse(self.path).path

    def _safe(self, fn):
        try:
            return fn()
        except Exception as e:
            traceback.print_exc()
            try:
                self._json({"error": f"服务端异常: {e}"}, 500)
            except Exception:
                pass

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        return self._safe(self._do_GET)

    # --------------------------------------------------------
    # GET 端点
    # --------------------------------------------------------
    def _do_GET(self):
        path = self._p()
        q = self._q()

        if path == "/api/ping":
            return self._json({"ok": True, "version": VERSION, "ts": time.time()})

        if path == "/api/shell/probe":
            checks = [
                ("python", shell_pick_python(), ["--version"]),
                ("pip", shell_pick_python(), ["-m", "pip", "--version"]),
                ("node", "node", ["--version"]),
                ("java", "java", ["-version"]),
                ("javac", "javac", ["-version"]),
            ]
            out = {}
            for name, cmd, args in checks:
                try:
                    p = subprocess.run([cmd] + args, capture_output=True,
                                       text=True, timeout=4)
                    txt = (p.stdout or "") + (p.stderr or "")
                    out[name] = {
                        "ok": p.returncode == 0,
                        "msg": txt.strip().split("\n")[0] if txt.strip() else ""
                    }
                except Exception as e:
                    out[name] = {"ok": False, "msg": str(e)[:120]}
            return self._json(out)

        if path == "/api/shell/stream":
            return self._handle_stream(q)

        if path == "/api/gfx/fetch":
            token = q.get("token", [""])[0]
            with _gfx_lock:
                item = _gfx_stage.pop(token, None)
            if not item:
                return self._json({"error": "token 无效或已过期"})
            return self._json({
                "ok": True, "name": item["name"],
                "lang": item["lang"], "code": item["code"],
            })

        if path == "/api/users/list":
            conn = db(); c = conn.cursor()
            c.execute("SELECT uuid, name FROM users ORDER BY created ASC")
            r = [{"uuid": x["uuid"], "name": x["name"]} for x in c.fetchall()]
            conn.close()
            return self._json({"users": r})

        if path == "/api/files/list":
            uid = q.get("uuid", [""])[0]
            scope = q.get("scope", ["private"])[0]
            dirpath = q.get("path", [""])[0]
            if not uid:
                return self._json({"files": [], "path": dirpath})
            try:
                target = full_path(uid, scope, dirpath)
            except Exception as e:
                return self._json({"error": str(e)})
            if not target.exists() or not target.is_dir():
                return self._json({"error": "目录不存在", "files": [], "path": dirpath})

            conn = db(); c = conn.cursor()
            c.execute("SELECT name, hidden FROM files WHERE uuid=? AND scope=?",
                      (db_uid(uid, scope), scope))
            db_rows = c.fetchall()
            hidden_map = {r["name"]: bool(r["hidden"]) for r in db_rows}
            user_top_names = set()
            for r in db_rows:
                n = r["name"]
                if "/" not in n:
                    user_top_names.add(n)
            conn.close()

            is_root = (dirpath == "")
            items = []
            try:
                for e in sorted(target.iterdir(),
                                key=lambda x: (not x.is_dir(), x.name.lower())):
                    rel = ((Path(dirpath) / e.name).as_posix()
                           if dirpath else e.name)
                    rel = rel.lstrip("/")
                    name = e.name
                    is_dir = e.is_dir()
                    is_system = False
                    if (is_root and is_dir
                            and name in SYSTEM_DIR_WHITELIST
                            and name not in user_top_names):
                        is_system = True
                    items.append({
                        "name": name, "path": rel, "is_dir": is_dir,
                        "size": e.stat().st_size if e.is_file() else 0,
                        "hidden": hidden_map.get(rel, False),
                        "is_system": is_system,
                        "user_created": not is_system,
                        "exists": True,
                    })
            except Exception as e:
                return self._json({"error": str(e)})
            return self._json({"files": items, "path": dirpath})

        if path == "/api/files/read":
            uid = q.get("uuid", [""])[0]
            scope = q.get("scope", ["private"])[0]
            name = q.get("name", [""])[0]
            if not uid or not name:
                return self._json({"error": "参数错误"})
            try:
                p = full_path(uid, scope, name)
            except ValueError as e:
                return self._json({"error": str(e)})
            if not p.exists() or not p.is_file():
                return self._json({"error": "文件不存在"})
            try:
                content = p.read_text(encoding="utf-8", errors="replace")
            except Exception as e:
                return self._json({"error": str(e)})
            return self._json({"content": content, "name": name})

        if path == "/api/files/raw":
            uid = q.get("uuid", [""])[0]
            scope = q.get("scope", ["private"])[0]
            name = q.get("name", [""])[0]
            if not uid or not name:
                return self._text("404", 404)
            try:
                p = full_path(uid, scope, name)
            except ValueError:
                return self._text("404", 404)
            if not p.exists() or not p.is_file():
                return self._text("404", 404)
            return self._file(p, False)

        if path == "/api/apk/info":
            uid = q.get("uuid", [""])[0]
            scope = q.get("scope", ["private"])[0]
            name = q.get("name", [""])[0]
            if not uid or not name:
                return self._json({"error": "参数错误"})
            try:
                p = full_path(uid, scope, name)
            except ValueError as e:
                return self._json({"error": str(e)})
            if not p.exists():
                return self._json({"error": "文件不存在"})
            parent = p.parent if p.is_file() else p
            meta_path = parent / "meta.json"
            if meta_path.exists():
                try:
                    m = json.loads(meta_path.read_text(encoding="utf-8"))
                except Exception:
                    m = {}
                kind, entry, _ = apk_find_entry(parent)
                root = user_root(uid, scope)
                try:
                    app_rel = str(parent.relative_to(root)).replace(os.sep, "/")
                except ValueError:
                    app_rel = parent.name
                return self._json({
                    "installed": True,
                    "pkg": m.get("package") or parent.name,
                    "name": m.get("source") or parent.name,
                    "kind": kind, "entry": entry,
                    "runnable": bool(kind),
                    "app_dir": app_rel,
                })
            return self._json({"installed": False, "name": name, "runnable": False})

        if path == "/api/apk/list":
            uid = q.get("uuid", [""])[0]
            scope = q.get("scope", ["private"])[0]
            if not uid:
                return self._json({"apps": []})
            try:
                root = user_root(uid, scope)
            except Exception:
                return self._json({"apps": []})
            apps_root = root / "apps"
            result = []
            if apps_root.exists():
                for d in sorted(apps_root.iterdir(), key=lambda x: x.name.lower()):
                    if not d.is_dir() or d.name.startswith(".stage_"):
                        continue
                    meta_path = d / "meta.json"
                    meta = {}
                    if meta_path.exists():
                        try:
                            meta = json.loads(meta_path.read_text(encoding="utf-8"))
                        except Exception:
                            meta = {}
                    kind, entry, _ = apk_find_entry(d)
                    has_icon = any((d / "content" / n).exists()
                                   for n in ("icon.png", "logo.png",
                                             "favicon.ico", "icon.ico"))
                    result.append({
                        "pkg": meta.get("package") or d.name,
                        "dir": f"apps/{d.name}",
                        "apk": f"apps/{d.name}/app.apk",
                        "name": meta.get("source") or d.name,
                        "installed_at": meta.get("installed_at_str", ""),
                        "entry": entry, "kind": kind,
                        "runnable": bool(kind),
                        "has_icon": has_icon,
                        "rewritten": meta.get("rewritten_paths", 0),
                    })
            return self._json({"apps": result, "path": "apps"})

        if path == "/api/apk/icon":
            uid = q.get("uuid", [""])[0]
            scope = q.get("scope", ["private"])[0]
            pkg = q.get("pkg", [""])[0]
            if not uid or not pkg:
                return self._text("404", 404)
            try:
                root = user_root(uid, scope)
            except Exception:
                return self._text("404", 404)
            try:
                app_dir = root / "apps" / safe_rel(pkg)
            except ValueError:
                return self._text("404", 404)
            if not app_dir.exists() or not app_dir.is_dir():
                return self._text("404", 404)
            for base in (app_dir / "content", app_dir):
                for n in ("icon.png", "logo.png", "favicon.ico", "icon.ico"):
                    p = base / n
                    if p.exists() and p.is_file():
                        return self._file(p, False)
            return self._text("404", 404)

        if path == "/api/messages/inbox":
            uid = q.get("uuid", [""])[0]
            conn = db(); c = conn.cursor()
            c.execute('''SELECT m.*, u.name AS from_name FROM messages m
                         LEFT JOIN users u ON m.from_uuid=u.uuid
                         WHERE m.to_uuid=? ORDER BY m.time DESC LIMIT 100''',
                      (uid,))
            rows = c.fetchall()
            c.execute("SELECT uuid, name FROM users")
            nm = {r["uuid"]: r["name"] for r in c.fetchall()}
            conn.close()
            return self._json({"messages": [{
                "from": r["from_uuid"],
                "from_name": r["from_name"] or nm.get(r["from_uuid"], "未知"),
                "to": r["to_uuid"],
                "to_name": nm.get(r["to_uuid"], "未知"),
                "content": r["content"],
                "time": datetime.fromtimestamp(r["time"]).strftime("%Y-%m-%d %H:%M:%S"),
            } for r in rows]})

        if path == "/api/messages/outbox":
            uid = q.get("uuid", [""])[0]
            conn = db(); c = conn.cursor()
            c.execute('''SELECT m.*, u.name AS to_name FROM messages m
                         LEFT JOIN users u ON m.to_uuid=u.uuid
                         WHERE m.from_uuid=? ORDER BY m.time DESC LIMIT 100''',
                      (uid,))
            rows = c.fetchall()
            c.execute("SELECT uuid, name FROM users")
            nm = {r["uuid"]: r["name"] for r in c.fetchall()}
            conn.close()
            return self._json({"messages": [{
                "from": r["from_uuid"],
                "from_name": nm.get(r["from_uuid"], "未知"),
                "to": r["to_uuid"],
                "to_name": r["to_name"] or nm.get(r["to_uuid"], "未知"),
                "content": r["content"],
                "time": datetime.fromtimestamp(r["time"]).strftime("%Y-%m-%d %H:%M:%S"),
            } for r in rows]})

        if path == "/api/progress":
            uid = q.get("uuid", [""])[0]
            with _progress_lock:
                p = _progress.get(uid)
                if p:
                    p = dict(p)
            if not p:
                return self._json({"status": "idle", "received": 0, "sentences": []})
            p.pop("job_id", None)
            return self._json(p)

        if path == "/api/tunnel":
            with _tunnel_lock:
                return self._json({"url": TUNNEL_URL,
                                   "online": TUNNEL_URL is not None})

        if path.startswith("/share/"):
            token = path[len("/share/"):]
            conn = db(); c = conn.cursor()
            c.execute("SELECT uuid, scope, name FROM shares WHERE token=?",
                      (token,))
            r = c.fetchone()
            conn.close()
            if not r:
                return self._text("分享链接无效", 404)
            try:
                p = full_path(r["uuid"], r["scope"], r["name"])
            except ValueError:
                return self._text("文件不存在", 404)
            if not p.exists():
                return self._text("文件不存在", 404)
            return self._file(p, True)

        if path == "/" or path == "":
            if not INDEX_HTML.exists():
                return self._text("index.html 未找到", 404)
            return self._file(INDEX_HTML, False)

        rel = unquote(path.lstrip("/"))
        if ".." in rel:
            return self._text("非法路径", 400)
        p = BASE_DIR / rel
        if p.exists() and p.is_file():
            return self._file(p, False)
        return self._text("404 Not Found", 404)

    def _handle_stream(self, q):
        sid = (q.get("sid", [""])[0] or "").strip()
        with _shell_sessions_lock:
            s = _shell_sessions.get(sid)
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Transfer-Encoding", "chunked")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        def _cw(b):
            self.wfile.write(f"{len(b):X}\r\n".encode("ascii"))
            self.wfile.write(b)
            self.wfile.write(b"\r\n")
            self.wfile.flush()

        def _ev(o):
            _cw(("data: " + json.dumps(o, ensure_ascii=False) + "\n\n")
                .encode("utf-8"))

        if not s:
            try:
                _ev({"type": "stderr", "data": "[会话不存在或已结束]\n"})
                _ev({"type": "exit", "code": -1})
            except Exception:
                pass
            try:
                self.wfile.write(b"0\r\n\r\n")
                self.wfile.flush()
            except Exception:
                pass
            return

        qq = s["queue"]
        proc = s["proc"]
        try:
            while True:
                try:
                    msg = qq.get(timeout=25)
                except queue.Empty:
                    _cw(b": keepalive\n\n")
                    if proc.poll() is not None:
                        try:
                            msg = qq.get_nowait()
                        except queue.Empty:
                            break
                    continue
                _ev(msg)
                if msg.get("type") == "exit":
                    with _shell_sessions_lock:
                        _shell_sessions.pop(sid, None)
                    break
        except (BrokenPipeError, ConnectionResetError):
            try:
                if proc.poll() is None:
                    proc.terminate()
            except Exception:
                pass
            with _shell_sessions_lock:
                _shell_sessions.pop(sid, None)
        except Exception as e:
            try:
                _ev({"type": "stderr", "data": f"[SSE 异常] {e}\n"})
                _ev({"type": "exit", "code": -1})
            except Exception:
                pass
            with _shell_sessions_lock:
                _shell_sessions.pop(sid, None)
        finally:
            try:
                self.wfile.write(b"0\r\n\r\n")
                self.wfile.flush()
            except Exception:
                pass
            try:
                if proc.stdin:
                    proc.stdin.close()
            except Exception:
                pass

    def do_POST(self):
        return self._safe(self._do_POST)

    # --------------------------------------------------------
    # POST 端点
    # --------------------------------------------------------
    def _do_POST(self):
        path = self._p()

        if path == "/api/gfx/stage":
            d = self._body()
            code = d.get("code", "")
            name = d.get("name", "")
            lang = d.get("lang", "python")
            token = secrets.token_urlsafe(16)
            now = time.time()
            with _gfx_lock:
                for k in list(_gfx_stage.keys()):
                    if now - _gfx_stage[k]["time"] > GFX_TTL:
                        del _gfx_stage[k]
                _gfx_stage[token] = {"name": name, "lang": lang,
                                     "code": code, "time": now}
            return self._json({"ok": True, "token": token})

        if path == "/api/shell/start":
            data = self._body()
            uid = data.get("uuid", "")
            if not uid:
                return self._json({"error": "uuid required"})
            try:
                root = shell_bootstrap_root(uid)
            except Exception as e:
                return self._json({"error": str(e)})

            cmdline = data.get("cmdline")
            lang = data.get("lang")
            code = data.get("code", "")
            fname = data.get("file")

            if cmdline:
                cmdline = rewrite_cmdline_paths(cmdline, root)
            if lang == "python" and code:
                code = rewrite_python_source(code, root)
            if cmdline:
                cmdline = extract_and_rewrite_python_in_cmd(cmdline, root)
            if cmdline and is_dangerous_command(cmdline):
                return self._json({"error": "命令被安全策略拦截"}, 403)

            try:
                if cmdline:
                    if os.name == "nt":
                        argv = ["cmd.exe", "/d", "/s", "/c", cmdline]
                    else:
                        argv = ["/bin/bash", "-lc", cmdline]
                elif lang == "python":
                    fp = root / (fname or f"main_{int(time.time()*1000)}.py")
                    fp.write_text(code or "", encoding="utf-8")
                    argv = [shell_pick_python(), str(fp)]
                elif lang in ("node", "js"):
                    fp = root / (fname or f"main_{int(time.time()*1000)}.js")
                    fp.write_text(code or "", encoding="utf-8")
                    argv = ["node", str(fp)]
                elif lang == "java":
                    fp = root / (fname or "Main.java")
                    fp.write_text(code or "", encoding="utf-8")
                    argv = ["java", str(fp)]
                else:
                    return self._json({"error": "unknown lang"})
            except Exception as e:
                return self._json({"error": str(e)})

            env = os.environ.copy()
            env.update({
                "PYTHONIOENCODING": "utf-8",
                "PYTHONUNBUFFERED": "1",
                "PYTHONPATH": str(shell_user_libs(uid)),
                "PIP_DISABLE_PIP_VERSION_CHECK": "1",
                "HOME": str(root / "home"),
                "USERPROFILE": str(root / "home"),
                "TMPDIR": str(root / "tmp"),
                "TEMP": str(root / "tmp"),
                "TMP": str(root / "tmp"),
                "PWD": str(root),
            })
            try:
                proc = subprocess.Popen(
                    argv, cwd=str(root), env=env,
                    stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE, bufsize=0, shell=False)
            except FileNotFoundError as e:
                return self._json({"error": f"命令不存在：{e}"}, 500)
            except Exception as e:
                return self._json({"error": f"启动失败：{e}"}, 500)

            sid = secrets.token_hex(12)
            qq = queue.Queue()
            with _shell_sessions_lock:
                _shell_sessions[sid] = {"proc": proc, "queue": qq,
                                        "uuid": uid, "cwd": str(root)}

            def reader(stream, tag):
                try:
                    for line in iter(stream.readline, b""):
                        qq.put({"type": tag,
                                "data": line.decode("utf-8", "replace")})
                except Exception:
                    pass

            def waiter():
                try:
                    proc.wait()
                except Exception:
                    pass
                qq.put({"type": "exit", "code": proc.returncode})

            threading.Thread(target=reader, args=(proc.stdout, "stdout"),
                             daemon=True).start()
            threading.Thread(target=reader, args=(proc.stderr, "stderr"),
                             daemon=True).start()
            threading.Thread(target=waiter, daemon=True).start()

            return self._json({"ok": True, "sid": sid,
                               "cwd": str(root),
                               "virtual_root": str(root)})

        if path == "/api/shell/input":
            data = self._body()
            sid = data.get("sid", "")
            text = data.get("data", "")
            with _shell_sessions_lock:
                s = _shell_sessions.get(sid)
            if not s:
                return self._json({"error": "no session"}, 404)
            try:
                s["proc"].stdin.write(text.encode("utf-8"))
                s["proc"].stdin.flush()
                return self._json({"ok": True})
            except Exception as e:
                return self._json({"error": str(e)}, 500)

        if path == "/api/shell/stop":
            data = self._body()
            sid = data.get("sid", "")
            with _shell_sessions_lock:
                s = _shell_sessions.get(sid)
            if s:
                try:
                    s["proc"].terminate()
                except Exception:
                    pass
                with _shell_sessions_lock:
                    _shell_sessions.pop(sid, None)
            return self._json({"ok": True})

        if path == "/api/register":
            d = self._body()
            name = (d.get("name") or "").strip()
            pwd = d.get("password") or ""
            if not name or not pwd:
                return self._json({"error": "请输入用户名和密码"})
            if len(name) > 32:
                return self._json({"error": "用户名过长"})
            conn = db(); c = conn.cursor()
            c.execute("SELECT uuid FROM users WHERE name=?", (name,))
            if c.fetchone():
                conn.close()
                return self._json({"error": "用户名已存在"})
            uid = str(uuidlib.uuid4())
            c.execute("INSERT INTO users (uuid,name,password,created) "
                      "VALUES (?,?,?,?)",
                      (uid, name, hash_pw(pwd), time.time()))
            conn.commit(); conn.close()
            return self._json({"uuid": uid, "name": name})

        if path == "/api/login":
            d = self._body()
            name = (d.get("name") or "").strip()
            pwd = d.get("password") or ""
            if not name or not pwd:
                return self._json({"error": "请输入用户名和密码"})
            conn = db(); c = conn.cursor()
            c.execute("SELECT uuid,name,password FROM users WHERE name=?",
                      (name,))
            r = c.fetchone()
            conn.close()
            if not r or r["password"] != hash_pw(pwd):
                return self._json({"error": "用户名或密码错误"})
            return self._json({"uuid": r["uuid"], "name": r["name"]})

        if path == "/api/files/write":
            d = self._body()
            uid = d.get("uuid", "")
            scope = d.get("scope", "private")
            name = d.get("name", "")
            content = d.get("content", "")
            if not uid or not name:
                return self._json({"ok": False, "error": "参数错误"})
            try:
                p = full_path(uid, scope, name)
            except ValueError as e:
                return self._json({"ok": False, "error": str(e)})
            if p.exists() and p.is_dir():
                return self._json({"ok": False, "error": "同名文件夹已存在"})
            p.parent.mkdir(parents=True, exist_ok=True)
            try:
                p.write_text(content, encoding="utf-8")
            except Exception as e:
                return self._json({"ok": False, "error": str(e)})
            rel = safe_rel(name)
            conn = db(); c = conn.cursor()
            c.execute("INSERT OR IGNORE INTO files "
                      "(uuid,scope,name,hidden,created) VALUES (?,?,?,0,?)",
                      (db_uid(uid, scope), scope, rel, time.time()))
            conn.commit(); conn.close()
            return self._json({"ok": True, "name": rel})

        if path == "/api/files/upload":
            d = self._body()
            uid = d.get("uuid", "")
            scope = d.get("scope", "private")
            name = d.get("name", "")
            content_b64 = d.get("content_b64", "")
            if not uid or not name:
                return self._json({"ok": False, "error": "参数错误"})
            try:
                p = full_path(uid, scope, name)
            except ValueError as e:
                return self._json({"ok": False, "error": str(e)})
            if p.exists() and p.is_dir():
                return self._json({"ok": False, "error": "同名文件夹已存在"})
            p.parent.mkdir(parents=True, exist_ok=True)
            try:
                raw = base64.b64decode(content_b64 or "")
                p.write_bytes(raw)
            except Exception as e:
                return self._json({"ok": False, "error": str(e)})
            rel = safe_rel(name)
            conn = db(); c = conn.cursor()
            c.execute("INSERT OR IGNORE INTO files "
                      "(uuid,scope,name,hidden,created) VALUES (?,?,?,0,?)",
                      (db_uid(uid, scope), scope, rel, time.time()))
            conn.commit(); conn.close()
            return self._json({"ok": True, "name": rel})

        if path == "/api/files/mkdir":
            d = self._body()
            uid = d.get("uuid", "")
            scope = d.get("scope", "private")
            name = d.get("name", "")
            if not uid or not name:
                return self._json({"ok": False, "error": "参数错误"})
            try:
                p = full_path(uid, scope, name)
            except ValueError as e:
                return self._json({"ok": False, "error": str(e)})
            if p.exists():
                return self._json({"ok": False, "error": "已存在同名文件或文件夹"})
            try:
                p.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                return self._json({"ok": False, "error": str(e)})
            rel = safe_rel(name)
            conn = db(); c = conn.cursor()
            c.execute("INSERT OR REPLACE INTO files "
                      "(uuid,scope,name,hidden,created) VALUES (?,?,?,0,?)",
                      (db_uid(uid, scope), scope, rel, time.time()))
            conn.commit(); conn.close()
            return self._json({"ok": True, "name": rel, "is_dir": True})

        if path == "/api/files/delete":
            d = self._body()
            uid = d.get("uid", "") or d.get("uuid", "")
            scope = d.get("scope", "private")
            name = d.get("name", "")
            try:
                p = full_path(uid, scope, name)
            except ValueError as e:
                return self._json({"ok": False, "error": str(e)})

            if not p.exists():
                return self._json({"ok": False, "deleted": False,
                                   "error": "文件不存在"})

            deleted_count = 0
            try:
                if p.is_dir():
                    for _, _, files in os.walk(str(p), topdown=False):
                        for _f in files:
                            deleted_count += 1
                    try:
                        shutil.rmtree(str(p), ignore_errors=False)
                    except Exception:
                        try:
                            p.rmdir()
                        except Exception:
                            pass
                else:
                    p.unlink()
                    deleted_count = 1
            except Exception as e:
                return self._json({"ok": False, "deleted": False,
                                   "error": str(e)})

            rel = safe_rel(name)
            conn = db(); c = conn.cursor()
            c.execute("DELETE FROM files WHERE uuid=? AND scope=? "
                      "AND (name=? OR name LIKE ?)",
                      (db_uid(uid, scope), scope, rel, rel + "/%"))
            c.execute("DELETE FROM shares WHERE uuid=? AND scope=? "
                      "AND (name=? OR name LIKE ?)",
                      (uid, scope, rel, rel + "/%"))
            conn.commit(); conn.close()
            return self._json({"ok": True, "deleted": True,
                               "count": deleted_count})

        if path == "/api/files/move":
            d = self._body()
            uid = d.get("uuid", "")
            scope = d.get("scope", "private")
            src = d.get("from", "")
            dst = d.get("to", "")
            if not uid or not src or not dst:
                return self._json({"ok": False, "error": "参数错误"})
            try:
                sp = full_path(uid, scope, src)
                dp = full_path(uid, scope, dst)
            except ValueError as e:
                return self._json({"ok": False, "error": str(e)})
            if not sp.exists():
                return self._json({"ok": False, "error": "源不存在"})
            if dp.exists():
                return self._json({"ok": False, "error": "目标已存在"})
            dp.parent.mkdir(parents=True, exist_ok=True)
            try:
                sp.rename(dp)
            except Exception as e:
                return self._json({"ok": False, "error": str(e)})
            rel_src = safe_rel(src)
            rel_dst = safe_rel(dst)
            conn = db(); c = conn.cursor()
            c.execute("UPDATE files SET name=? WHERE uuid=? AND scope=? "
                      "AND name=?",
                      (rel_dst, db_uid(uid, scope), scope, rel_src))
            c.execute("SELECT name FROM files WHERE uuid=? AND scope=? "
                      "AND name LIKE ?",
                      (db_uid(uid, scope), scope, rel_src + "/%"))
            subs = [r["name"] for r in c.fetchall()]
            for s in subs:
                new = rel_dst + s[len(rel_src):]
                c.execute("UPDATE files SET name=? WHERE uuid=? AND scope=? "
                          "AND name=?",
                          (new, db_uid(uid, scope), scope, s))
            conn.commit(); conn.close()
            return self._json({"ok": True, "from": rel_src, "to": rel_dst})

        if path == "/api/files/hide":
            d = self._body()
            uid = d.get("uuid", "")
            scope = d.get("scope", "private")
            name = d.get("name", "")
            hidden = 1 if d.get("hidden") else 0
            rel = safe_rel(name)
            conn = db(); c = conn.cursor()
            c.execute("UPDATE files SET hidden=? WHERE uuid=? AND scope=? "
                      "AND name=?",
                      (hidden, db_uid(uid, scope), scope, rel))
            if c.rowcount == 0:
                c.execute("INSERT INTO files "
                          "(uuid,scope,name,hidden,created) VALUES (?,?,?,?,?)",
                          (db_uid(uid, scope), scope, rel, hidden, time.time()))
            conn.commit(); conn.close()
            return self._json({"ok": True})

        if path == "/api/files/zip":
            d = self._body()
            uid = d.get("uuid", "")
            scope = d.get("scope", "private")
            name = d.get("name", "")
            if not uid or not name:
                return self._json({"ok": False, "error": "参数错误"})
            try:
                src = full_path(uid, scope, name)
            except ValueError as e:
                return self._json({"ok": False, "error": str(e)})
            if not src.exists():
                return self._json({"ok": False, "error": "文件不存在"})

            base = src.name
            if src.is_dir():
                stem = base
            else:
                if base.lower().endswith(".zip"):
                    return self._json({"ok": False, "error": "这已经是一个 ZIP 文件"})
                stem = os.path.splitext(base)[0] or base

            parent = src.parent
            target = parent / (stem + ".zip")
            i = 1
            while target.exists():
                target = parent / (stem + "_" + str(i) + ".zip")
                i += 1

            try:
                with zipfile.ZipFile(str(target), "w",
                                     zipfile.ZIP_DEFLATED) as zf:
                    if src.is_dir():
                        for root_d, _, files in os.walk(str(src)):
                            for f in files:
                                fp = Path(root_d) / f
                                try:
                                    arc = fp.relative_to(src.parent).as_posix()
                                except ValueError:
                                    arc = f
                                zf.write(str(fp), arc)
                    else:
                        zf.write(str(src), base)
            except Exception as e:
                try:
                    if target.exists():
                        target.unlink()
                except Exception:
                    pass
                return self._json({"ok": False, "error": str(e)})

            root = user_root(uid, scope)
            try:
                rel = target.relative_to(root).as_posix()
            except ValueError:
                rel = target.name

            conn = db(); c = conn.cursor()
            c.execute("INSERT OR IGNORE INTO files "
                      "(uuid,scope,name,hidden,created) VALUES (?,?,?,0,?)",
                      (db_uid(uid, scope), scope, rel, time.time()))
            conn.commit(); conn.close()
            return self._json({"ok": True, "name": rel})

        if path == "/api/files/unzip":
            d = self._body()
            uid = d.get("uuid", "")
            scope = d.get("scope", "private")
            name = d.get("name", "")
            if not uid or not name:
                return self._json({"ok": False, "error": "参数错误"})
            try:
                src = full_path(uid, scope, name)
            except ValueError as e:
                return self._json({"ok": False, "error": str(e)})
            if not src.exists() or not src.is_file():
                return self._json({"ok": False, "error": "文件不存在"})
            if not src.name.lower().endswith(".zip"):
                return self._json({"ok": False, "error": "不是 ZIP 文件"})

            try:
                raw = read_file_bytes_smart(src)
            except Exception as e:
                return self._json({"ok": False, "error": f"读取失败：{e}"})

            if not raw.startswith(b'PK'):
                return self._json({"ok": False, "error": "ZIP 文件已损坏或格式不正确"})

            stem = src.name[:-4] or "extracted"
            parent = src.parent
            target = parent / stem
            i = 1
            while target.exists():
                target = parent / (stem + "_" + str(i))
                i += 1

            try:
                target.mkdir(parents=True, exist_ok=True)
                count = 0
                with zipfile.ZipFile(io.BytesIO(raw), "r") as zf:
                    for info in zf.infolist():
                        norm = (info.filename or "").replace("\\", "/").lstrip("/")
                        if not norm:
                            continue
                        parts = [p for p in norm.split("/") if p and p != "."]
                        if ".." in parts:
                            continue
                        if info.is_dir():
                            (target / norm).mkdir(parents=True, exist_ok=True)
                            continue
                        try:
                            out_p = target / norm
                            out_p.parent.mkdir(parents=True, exist_ok=True)
                            with zf.open(info, "r") as fin, \
                                 open(str(out_p), "wb") as fout:
                                shutil.copyfileobj(fin, fout)
                            count += 1
                        except Exception:
                            continue
            except zipfile.BadZipFile:
                try:
                    shutil.rmtree(str(target), ignore_errors=True)
                except Exception:
                    pass
                return self._json({"ok": False, "error": "ZIP 文件已损坏或格式不正确"})
            except Exception as e:
                try:
                    shutil.rmtree(str(target), ignore_errors=True)
                except Exception:
                    pass
                return self._json({"ok": False, "error": str(e)})

            root = user_root(uid, scope)
            try:
                rel = target.relative_to(root).as_posix()
            except ValueError:
                rel = target.name

            conn = db(); c = conn.cursor()
            c.execute("INSERT OR REPLACE INTO files "
                      "(uuid,scope,name,hidden,created) VALUES (?,?,?,0,?)",
                      (db_uid(uid, scope), scope, rel, time.time()))
            conn.commit(); conn.close()
            return self._json({"ok": True, "name": rel, "count": count})

        if path == "/api/files/share":
            d = self._body()
            uid = d.get("uuid", "")
            scope = d.get("scope", "private")
            name = d.get("name", "")
            try:
                p = full_path(uid, scope, name)
            except ValueError as e:
                return self._json({"ok": False, "error": str(e)})
            if not p.exists() or not p.is_file():
                return self._json({"ok": False, "error": "文件不存在"})
            rel = safe_rel(name)
            conn = db(); c = conn.cursor()
            c.execute("SELECT token FROM shares WHERE uuid=? AND scope=? "
                      "AND name=? ORDER BY created DESC LIMIT 1",
                      (uid, scope, rel))
            ex = c.fetchone()
            if ex:
                conn.close()
                return self._json({
                    "ok": True,
                    "url": f"{get_public_base(self)}/share/{ex['token']}",
                    "reused": True,
                })
            token = secrets.token_urlsafe(16)
            c.execute("INSERT INTO shares "
                      "(token,uuid,scope,name,created) VALUES (?,?,?,?,?)",
                      (token, uid, scope, rel, time.time()))
            conn.commit(); conn.close()
            return self._json({
                "ok": True,
                "url": f"{get_public_base(self)}/share/{token}",
                "reused": False,
            })

        if path == "/api/apk/install":
            d = self._body()
            uid = d.get("uuid", "")
            scope = d.get("scope", "private")
            name = d.get("name", "")
            if not uid or not name:
                return self._json({"ok": False, "error": "参数错误"})
            try:
                res = apk_install(uid, scope, name)
            except Exception as e:
                return self._json({"ok": False, "error": str(e)})
            return self._json(res)

        if path == "/api/apk/run":
            d = self._body()
            uid = d.get("uuid", "")
            scope = d.get("scope", "private")
            name = d.get("name", "")
            if not uid or not name:
                return self._json({"ok": False, "error": "参数错误"})

            try:
                p = full_path(uid, scope, name)
            except ValueError as e:
                return self._json({"ok": False, "error": str(e)})

            app_dir = p.parent if p.is_file() else p
            meta_path = app_dir / "meta.json"
            if not meta_path.exists():
                return self._json({"ok": False, "error": "该应用尚未安装"})

            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                meta = {}

            kind, entry, entry_path = apk_find_entry(app_dir)

            if not entry_path:
                return self._json({
                    "ok": False, "error": "native_android",
                    "pkg": meta.get("package") or app_dir.name,
                    "name": meta.get("source") or app_dir.name,
                    "reason": ("这是一个原生 Android 应用（APK），"
                               "只能在手机上安装运行，无法在电脑模拟桌面里启动。"),
                })

            root = user_root(uid, scope)
            try:
                rel = entry_path.relative_to(root).as_posix()
            except ValueError:
                return self._json({"ok": False, "error": "路径异常"})

            return self._json({
                "ok": True, "kind": kind, "entry": entry, "file": rel,
                "pkg": meta.get("package") or app_dir.name,
            })

        if path == "/api/apk/uninstall":
            d = self._body()
            uid = d.get("uuid", "")
            scope = d.get("scope", "private")
            pkg = d.get("pkg", "")
            if not uid or not pkg:
                return self._json({"ok": False, "error": "参数错误"})
            try:
                root = user_root(uid, scope)
            except Exception as e:
                return self._json({"ok": False, "error": str(e)})
            try:
                rel = safe_rel(pkg)
            except ValueError as e:
                return self._json({"ok": False, "error": str(e)})
            if not rel.startswith("apps/"):
                return self._json({"ok": False, "error": "非法路径"})
            app_dir = root / rel
            if not app_dir.exists() or not app_dir.is_dir():
                return self._json({"ok": False, "error": "应用不存在"})
            try:
                shutil.rmtree(str(app_dir), ignore_errors=False)
            except Exception as e:
                return self._json({"ok": False, "error": str(e)})
            return self._json({"ok": True})

        if path == "/api/messages/send":
            d = self._body()
            uid = d.get("uuid", "")
            to = (d.get("to") or "").strip()
            content = d.get("content", "")
            if not uid or not to or not content:
                return self._json({"error": "参数不完整"})
            conn = db(); c = conn.cursor()
            c.execute("SELECT uuid,name FROM users WHERE uuid=? OR name=?",
                      (to, to))
            t = c.fetchone()
            if not t:
                conn.close()
                return self._json({"error": "收件人不存在"})
            c.execute("INSERT INTO messages "
                      "(from_uuid,to_uuid,content,time) VALUES (?,?,?,?)",
                      (uid, t["uuid"], content, time.time()))
            conn.commit(); conn.close()
            return self._json({"ok": True})

        if path == "/api/generate":
            d = self._body()
            uid = d.get("uuid", "")
            if not uid:
                return self._json({"error": "参数错误"})
            job_id = secrets.token_hex(8)
            with _progress_lock:
                _progress[uid] = {"status": "generating", "received": 0,
                                  "sentences": [], "job_id": job_id}
            threading.Thread(target=generate_sentences,
                             args=(uid, job_id), daemon=True).start()
            return self._json({"ok": True, "job_id": job_id})

        return self._json({"error": "未知接口"}, 404)


# ============================================================
# 主程序
# ============================================================
if __name__ == "__main__":
    print("=" * 60)
    print(f"  Win10 模拟桌面  -  后端  v{VERSION}")
    print("=" * 60)
    print(f"  ntfy topic : {NTFY_TOPIC}")
    print(f"  本地端口   : {PORT}")
    print("=" * 60)

    ensure_ollama()
    start_tunnel(PORT)

    print(f"[服务] http://localhost:{PORT}")
    print("=" * 60)
    print("  按 Ctrl+C 停止服务")
    print("=" * 60)

    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[退出] 正在停止隧道...")
        stop_tunnel()
        httpd.server_close()
        print("[退出] 完成")