// shell-server.js —— CMD Shell 后端（真实子进程 + 流式输出 + 交互输入）
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawn } = require('child_process');

const STORAGE = path.resolve(process.env.SHELL_STORAGE || './storage');
fs.mkdirSync(STORAGE, { recursive: true });

function userRoot(uuid) {
  if (!/^[a-zA-Z0-9_\-]{1,64}$/.test(uuid || '')) throw new Error('bad uuid');
  const d = path.join(STORAGE, uuid);
  fs.mkdirSync(d, { recursive: true });
  return d;
}
function userPrivate(uuid) {
  const d = path.join(userRoot(uuid), 'private');
  fs.mkdirSync(d, { recursive: true });
  return d;
}
function safeJoin(base, rel) {
  const p = path.resolve(base, rel);
  if (p !== base && !p.startsWith(base + path.sep)) throw new Error('path escape');
  return p;
}

const sessions = new Map(); // sid -> { proc, uuid, cwd }

function pickPython() {
  return process.platform === 'win32' ? 'python' : 'python3';
}

function registerShellRoutes(app) {

  // 环境探测
  app.get('/api/shell/probe', (req, res) => {
    const checks = [
      { name: 'python', cmd: pickPython(), args: ['--version'] },
      { name: 'pip',    cmd: pickPython(), args: ['-m', 'pip', '--version'] },
      { name: 'node',   cmd: 'node',       args: ['--version'] },
      { name: 'java',   cmd: 'java',       args: ['-version'] },
      { name: 'javac',  cmd: 'javac',      args: ['-version'] }
    ];
    let done = 0; const out = {};
    function finish() { done++; if (done === checks.length) res.json(out); }
    checks.forEach(c => {
      let p;
      try { p = spawn(c.cmd, c.args, { stdio: ['ignore','pipe','pipe'] }); }
      catch (e) { out[c.name] = { ok: false, msg: e.message }; finish(); return; }
      let buf = '';
      p.stdout.on('data', b => buf += b.toString());
      p.stderr.on('data', b => buf += b.toString());
      p.on('error', e => { out[c.name] = { ok: false, msg: e.message }; finish(); });
      p.on('close', code => {
        out[c.name] = { ok: code === 0, msg: buf.trim().split('\n')[0] || '' };
        finish();
      });
    });
  });

  // 启动会话（lang+code 或 cmdline）
  app.post('/api/shell/start', (req, res) => {
    const { uuid, lang, file, code, cmdline } = req.body || {};
    if (!uuid) return res.status(400).json({ error: 'uuid required' });

    let cwd;
    try { cwd = userPrivate(uuid); }
    catch (e) { return res.status(400).json({ error: e.message }); }

    let exe, argv = [];
    try {
      if (cmdline) {
        if (process.platform === 'win32') {
          exe = 'cmd.exe'; argv = ['/d', '/s', '/c', cmdline];
        } else {
          exe = '/bin/bash'; argv = ['-lc', cmdline];
        }
      } else if (lang === 'python') {
        const fp = safeJoin(cwd, file || ('main_' + Date.now() + '.py'));
        fs.writeFileSync(fp, code || '');
        exe = pickPython(); argv = [fp];
      } else if (lang === 'node' || lang === 'js') {
        const fp = safeJoin(cwd, file || ('main_' + Date.now() + '.js'));
        fs.writeFileSync(fp, code || '');
        exe = 'node'; argv = [fp];
      } else if (lang === 'java') {
        const fp = safeJoin(cwd, file || 'Main.java');
        fs.writeFileSync(fp, code || '');
        exe = 'java'; argv = [fp]; // 需 JDK 11+，单文件源码启动
      } else {
        return res.status(400).json({ error: 'unknown lang' });
      }
    } catch (e) { return res.status(400).json({ error: e.message }); }

    const env = Object.assign({}, process.env, {
      PYTHONIOENCODING: 'utf-8',
      PYTHONUNBUFFERED: '1',
      PYTHONPATH: path.join(userRoot(uuid), 'libs')
    });

    let proc;
    try { proc = spawn(exe, argv, { cwd, env }); }
    catch (e) { return res.status(500).json({ error: 'spawn failed: ' + e.message }); }

    const sid = crypto.randomBytes(12).toString('hex');
    sessions.set(sid, { proc, uuid, cwd });
    res.json({ ok: true, sid });
  });

  // SSE 流式输出
  app.get('/api/shell/stream', (req, res) => {
    const sid = String(req.query.sid || '');
    const s = sessions.get(sid);
    if (!s) return res.status(404).end();

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders && res.flushHeaders();

    const send = (obj) => { try { res.write('data: ' + JSON.stringify(obj) + '\n\n'); } catch(e){} };

    const onOut = (b) => send({ type: 'stdout', data: b.toString('utf-8') });
    const onErr = (b) => send({ type: 'stderr', data: b.toString('utf-8') });
    s.proc.stdout.on('data', onOut);
    s.proc.stderr.on('data', onErr);

    s.proc.on('close', (code, sig) => {
      send({ type: 'exit', code: code, sig: sig });
      try { res.end(); } catch(e){}
      sessions.delete(sid);
    });

    req.on('close', () => {
      try { s.proc.stdout.off('data', onOut); s.proc.stderr.off('data', onErr); } catch(e){}
      try { res.end(); } catch(e){}
    });
  });

  // 向 stdin 写入（交互输入）
  app.post('/api/shell/input', (req, res) => {
    const { sid, data } = req.body || {};
    const s = sessions.get(sid);
    if (!s) return res.status(404).json({ error: 'no session' });
    try { s.proc.stdin.write(String(data == null ? '' : data)); return res.json({ ok: true }); }
    catch (e) { return res.status(500).json({ error: e.message }); }
  });

  // 中断
  app.post('/api/shell/stop', (req, res) => {
    const { sid } = req.body || {};
    const s = sessions.get(sid);
    if (s) { try { s.proc.kill('SIGTERM'); } catch(e){} sessions.delete(sid); }
    res.json({ ok: true });
  });
}

module.exports = { registerShellRoutes };